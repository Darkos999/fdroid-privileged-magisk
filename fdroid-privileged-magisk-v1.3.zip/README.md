# F-Droid Privileged Extension (Module Magisk)

Ce module Magisk installe **F-Droid Privileged Extension** en tant que service système Android, permettant à F-Droid d’installer et mettre à jour automatiquement des applications open source 🔄.

---

## 📦 Contenu du module

- `org.fdroid.fdroid.privileged.apk` : l’extension système F-Droid
- `install.sh` : script d’installation pour Magisk
- `module.prop` : métadonnées du module
- `update.json` : informations de mise à jour pour Magisk Manager
- `f-droid-privileged.zip` : archive finale du module

---

## ⚙️ Installation

1. Télécharge `f-droid-privileged.zip` depuis [le dépôt GitHub](https://github.com/TON_UTILISATEUR_GITHUB/f-droid-privileged).
2. Ouvre Magisk Manager.
3. Va dans **Modules > Installer depuis un fichier ZIP**.
4. Sélectionne le fichier et redémarre ton appareil.

---

## 🔁 Mises à jour automatiques

Le module utilise Magisk Manager pour détecter les mises à jour grâce à `update.json`.

```properties
updateJson=https://raw.githubusercontent.com/TON_UTILISATEUR_GITHUB/f-droid-privileged/main/update.json


## 📜 Licence

Ce projet est distribué sous la licence [GNU GPLv3](https://www.gnu.org/licenses/gpl-3.0.fr.html).