#!/system/bin/sh

APK="org.fdroid.fdroid.privileged.apk"
TARGETDIR="$MODPATH/system/priv-app/org.fdroid.fdroid.privileged"
APK_SRC="$MODPATH/files/$APK"

ui_print "📦 Installation du module F-Droid Privileged Extension..."

if [ ! -f "$APK_SRC" ]; then
  ui_print "❌ Fichier APK introuvable : $APK_SRC"
  exit 1
fi

mkdir -p "$TARGETDIR"
cp -f "$APK_SRC" "$TARGETDIR/$APK"

chmod 644 "$TARGETDIR/$APK"
chown 1000:1000 "$TARGETDIR/$APK"

ui_print "✅ Installation terminée !"