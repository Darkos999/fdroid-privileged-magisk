#!/system/bin/sh

ui_print "📦 Installation du module F-Droid Privileged Extension..."
ui_print "✅ Installation terminée !"